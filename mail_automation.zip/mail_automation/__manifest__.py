# -*- coding: utf-8 -*-
{
    'name': 'Mail Automation',
    'depends': ['mail', 'base_automation'],
    'data': [
    ],
    'qweb': [
    ],
    'auto_install': True,
}
